/*
 * Module dependencies
 */
var express = require('express')
  , stylus = require('stylus')
  , nib = require('nib')

  var sys = require('sys')
  var exec = require('child_process').exec;
  var child;
 
 var app = express()
function compile(str, path) {
  return stylus(str)
    .set('filename', path)
    .use(nib())
}
app.set('views', __dirname + '/views')
app.set('view engine', 'jade')
app.use(express.logger('dev'))
app.use(stylus.middleware(
  { src: __dirname + '/public'
  , compile: compile
  }
))
app.use(express.static(__dirname + '/public'))
console.log("App run at localhost:3000")
app.get('/', function (req, res) {
  res.render('default',
  { title : 'Mini Demix Module - Galileo Contest - MDO HVE VN' }
  )
})

app.get('/inputvids', function (req, res) {
  res.render('inputbox',
  { title : 'Input VIDs list' }
  )
})

app.get('/submit', function (req, res) {
   
  res.end('submit clicked')
  
})

app.get('/checkcamera', function (req, res) {
  console.log("Checking camera readiness")
  res.render('default',
  { title : 'Mini Demix Module - Galileo Contest - MDO HVE VN' }
  )
  })
  
app.get('/takepicture', function (req, res) {
  console.log("taking picture")
//  exec("Python readrecipe.py")


	// executes image processing
	child = exec("python readrecipe.py", function (error, stdout, stderr) {
	  sys.print('stdout: ' + stdout);
	  sys.print('stderr: ' + stderr);
	  if (error !== null) {
	    console.log('exec error: ' + error);
	  }
	})

  res.render('result2',
  { title : 'Mini Demix Module - Galileo Contest - MDO HVE VN' }
  )
  
})

/*
app.get('/', function (req, res) {
  res.end('Hi there!')
})
*/
app.listen(3000)
