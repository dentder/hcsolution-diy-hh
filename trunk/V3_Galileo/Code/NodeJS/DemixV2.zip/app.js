/*
 * App to create web for Galileo
 * Hoang Hai version 1.0
 */
var express = require('express') // us
  , stylus = require('stylus')
  , nib = require('nib')

  var sys = require('sys')
  var exec = require('child_process').exec;
  var child;
  var fs = require('fs');
  var app = express()
 // var bodyParser     = require('body-parser');
 // var methodOverride = require('method-override');
  var multer  = require('multer')



function compile(str, path) {
  return stylus(str)
    .set('filename', path)
    .use(nib())
}
app.set('views', __dirname + '/views')
app.set('view engine', 'jade')
app.use(express.logger('dev'))
app.use(stylus.middleware(
  { src: __dirname + '/public'
  , compile: compile
  }
))
app.use(multer({
        dest: './public/uploads/',
        rename: function (fieldname, filename) {
            return filename.replace(/\W+/g, '-').toLowerCase();
        }
    }));
app.use(express.static(__dirname + '/public'))
console.log("App run at localhost:3000")


app.get('/', function (req, res) {
  res.render('default',
  { title : 'Mini Demix Module - Galileo Contest - MDO HVE VN' }
  )
})

/*
app.get('/inputvids', function (req, res) {
  res.render('inputbox',
  { title : 'Input VIDs list' }
  )
})
*/
app.get('/upload', function (req, res) {
  res.render('Upload',
  { title : 'Upload VIDs list' }
  )
})

app.post('/upload', function(req, res) {
  console.log('log: POST Upload : ')
  console.log(req.body)
  console.log('log: req.files.displayImage.path: ' + req.files.displayImage.path );
  console.log('log: req.files.displayImage.name: ' + req.files.displayImage.name );
  /*
  fs.readFile(req.files.displayImage.path, function (err, data) {
 
    var newPath = __dirname + "/uploads/"+req.files.displayImage.name;
    console.log('newPath = '+ newPath);
    fs.writeFile(newPath, data, function (err) {
      if (err) throw err;
      res.redirect("back");
      console.log('File upload is done');
    });
  });
  */
  res.redirect("back");  // TODO: send to user upload done
});

app.get('/submit', function (req, res) {
   
  res.end('submit clicked')
  
})

app.get('/checkcamera', function (req, res) {
  console.log("Checking camera readiness")
  res.render('default',
  { title : 'Mini Demix Module - Galileo Contest - MDO HVE VN' }
  )
  })
  
app.get('/takepicture', function (req, res) {
  console.log("taking picture")
//  exec("Python readrecipe.py")


	// executes image processing
	child = exec("python readrecipe.py", function (error, stdout, stderr) {
	  sys.print('stdout: ' + stdout);
	  sys.print('stderr: ' + stderr);
	  if (error !== null) {
	    console.log('exec error: ' + error);
	  }
	})

  res.render('result2',
  { title : 'Mini Demix Module - Galileo Contest - MDO HVE VN' }
  )
  
})

/*
app.get('/', function (req, res) {
  res.end('Hi there!')
})
*/
app.listen(3000)
